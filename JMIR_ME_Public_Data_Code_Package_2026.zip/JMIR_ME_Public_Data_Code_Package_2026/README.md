# Global medical education activity on a general-purpose generative AI platform

## Repository contents
This package contains aggregate, analysis-ready datasets and executable analysis code supporting the cross-national ecological study of medical education activity on a general-purpose generative AI platform. All files are at country, US-state, domain, or global aggregate level. No individual-level records or personally identifiable information are included.

May 2026 is the primary analysis month. April 2026 is used for adjacent-month sensitivity analyses. Publisher-suppressed or unpublished cells are retained as missing values and are never recoded as zero.

## Directory structure
- `data/`: analysis-ready aggregate datasets used by the statistical analyses.
- `results/`: principal numerical outputs reproduced from the analysis-ready datasets.
- `code/`: executable Python scripts for input checks, principal share-based analyses, the common-country cross-domain omnibus model, and Figure 2 panel A generation.
- `documentation/`: data dictionary, source notes, and file manifest.

## Execution
Install the packages listed in `requirements.txt`, then run:

```bash
python code/run_all.py
```

The scripts use only relative paths within this repository. Reproduced outputs are written to a new `generated/` directory.

## Analytical conventions
AUI is the publisher-defined usage-per-capita index. Education and medical-education percentages are compositional shares of platform activity, not counts of users. The population-relative medical-education activity index is a derived ecological index and should not be interpreted as user prevalence, access, or learning outcome. Share-based regressions use log-ratio outcomes. Missing publication cells remain missing.

For the primary common-country cross-domain model, four domains are compared within the same set of countries using country-clustered inference. US-state analyses are sensitivity analyses and should not be interpreted as a complete within-country replication.

## Data provenance
The analysis-ready files are derived from publicly available aggregate sources described in `documentation/SOURCE_NOTES.md`. The package does not contain raw conversation content or source-platform account data.
