# Source notes

The analysis-ready datasets in this package were constructed from public aggregate sources.

1. **Anthropic Economic Index / Claude activity data** — May 2026 is the primary period and April 2026 is the adjacent-month sensitivity period. The study uses published aggregate activity shares and the publisher-defined usage-per-capita index. API activity is outside the study scope.
2. **World Bank World Development Indicators** — GDP per capita, PPP; individuals using the Internet; and gross tertiary enrollment. Country-level values are matched to the May 2026 analysis frame. For tertiary enrollment, the retained source year identifies the most recent nonmissing observation used in the analysis.
3. **OpenAI Signals** — country-level population-normalized usage rank for 2026 Q2, used only as an external comparison of general platform-use geography. The rank is ordinal and is not treated as an intensity measure.

Third-party source data remain subject to the terms of their original publishers. This package redistributes only the aggregate analysis-ready extracts needed to reproduce the reported analyses.
