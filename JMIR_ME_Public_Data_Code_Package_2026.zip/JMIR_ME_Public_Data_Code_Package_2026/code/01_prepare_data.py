from pathlib import Path
import pandas as pd, numpy as np
ROOT=Path(__file__).resolve().parents[1]
may=pd.read_csv(ROOT/'data/country_may_2026.csv')
apr=pd.read_csv(ROOT/'data/country_april_2026.csv')
assert may['aui'].notna().sum()==121
assert may['medical_education_share_pct'].notna().sum()==80
assert apr['aui'].notna().sum()==114
assert apr['medical_education_share_pct'].notna().sum()==66
calc=np.log(may.education_learning_share_pct/(100-may.education_learning_share_pct))
assert np.nanmax(np.abs(calc-may.education_vs_noneducation_log_ratio))<1e-10
print('Input QC passed')
