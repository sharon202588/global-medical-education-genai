from pathlib import Path
import pandas as pd
import numpy as np
from scipy import stats
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'generated'
OUT.mkdir(exist_ok=True)
may = pd.read_csv(ROOT / 'data' / 'country_may_2026.csv')
apr = pd.read_csv(ROOT / 'data' / 'country_april_2026.csv')

def spearman(d, x, y):
    q = d[[x, y]].dropna()
    rho, p = stats.spearmanr(q[x], q[y])
    return len(q), rho, p

rows = []
for month, d in [('May 2026', may), ('April 2026', apr)]:
    for label, outcome in [
        ('Education vs noneducation', 'education_vs_noneducation_log_ratio'),
        ('Medical education vs other education', 'medical_vs_other_education_log_ratio'),
    ]:
        q = d[['aui', outcome]].dropna().copy()
        q['logaui'] = np.log(q.aui)
        model = sm.OLS(q[outcome], sm.add_constant(q[['logaui']])).fit(cov_type='HC3')
        n, rho, rho_p = spearman(q, 'aui', outcome)
        rows.append([month, label, n, rho, rho_p, model.params['logaui'], model.pvalues['logaui']])

pd.DataFrame(
    rows,
    columns=['month', 'outcome', 'n', 'rho', 'rho_p', 'slope', 'slope_p'],
).to_csv(OUT / 'share_relationships_reproduced.csv', index=False)
print('Primary analyses completed')
