import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
for script in [
    "01_prepare_data.py",
    "02_main_analyses.py",
    "03_advanced_models.py",
    "04_make_figures.py",
]:
    subprocess.run([sys.executable, str(root / script)], check=True)
print("Analysis completed")
