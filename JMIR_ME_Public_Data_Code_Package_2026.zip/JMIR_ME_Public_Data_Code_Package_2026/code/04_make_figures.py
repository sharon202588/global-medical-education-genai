from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'generated'
OUT.mkdir(exist_ok=True)
d = pd.read_csv(ROOT / 'data' / 'country_may_2026.csv')
q = d[['aui', 'education_vs_noneducation_log_ratio']].dropna().copy()
q['share'] = 100 * np.exp(q.education_vs_noneducation_log_ratio) / (1 + np.exp(q.education_vs_noneducation_log_ratio))
q['logaui'] = np.log(q.aui)
model = sm.OLS(q.education_vs_noneducation_log_ratio, sm.add_constant(q[['logaui']])).fit(cov_type='HC3')
grid = np.linspace(q.logaui.min(), q.logaui.max(), 200)
pred = model.get_prediction(sm.add_constant(pd.DataFrame({'logaui': grid}))).summary_frame()
inv = lambda z: 100 * np.exp(z) / (1 + np.exp(z))

fig, ax = plt.subplots(figsize=(5, 4))
ax.scatter(q.aui, q.share, s=14, alpha=.6)
ax.plot(np.exp(grid), inv(pred['mean']))
ax.set_xscale('log')
ax.set_xlabel('AUI')
ax.set_ylabel('Education share (%)')
fig.tight_layout()
fig.savefig(OUT / 'Figure2_panelA.pdf')
plt.close(fig)
print('Figure generated')
