from pathlib import Path
import pandas as pd
import numpy as np
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.sandwich_covariance import cov_cluster

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'generated'
OUT.mkdir(exist_ok=True)
D = pd.read_csv(ROOT / 'data' / 'education_domains_balanced_apr_may.csv')
rows = []

for month in ['May 2026', 'April 2026']:
    d = D[(D.month == month) & D.domain.isin([
        'Medical education', 'Programming education', 'Financial education', 'Math tutoring'
    ])].dropna().copy()
    complete = d.groupby('iso3').domain.nunique()
    complete = complete[complete == 4].index
    d = d[d.iso3.isin(complete)]
    d['logaui'] = np.log(d.aui)
    d['domain'] = pd.Categorical(
        d.domain,
        categories=['Medical education', 'Financial education', 'Math tutoring', 'Programming education'],
    )
    model = smf.ols(
        "domain_concentration_log_ratio ~ logaui * C(domain, Treatment(reference='Medical education'))",
        data=d,
    ).fit()
    V = cov_cluster(model, d.iso3, use_correction=True)
    terms = [t for t in model.params.index if t.startswith('logaui:C(domain')]
    idx = [model.params.index.get_loc(t) for t in terms]
    b = model.params.iloc[idx].to_numpy()
    VV = V[np.ix_(idx, idx)]
    wald = float(b.T @ np.linalg.inv(VV) @ b)
    p_value = float(stats.chi2.sf(wald, 3))
    rows.append([month, len(complete), len(d), wald, 3, p_value])

pd.DataFrame(
    rows,
    columns=['month', 'countries_n', 'observations_n', 'wald_chi2', 'df', 'p_value'],
).to_csv(OUT / 'domain_model_omnibus_reproduced.csv', index=False)
print('Cross-domain analyses completed')
